package model;

import java.util.ArrayList;
import java.io.*; 
import java.util.Scanner;
import java.util.Set;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

class Jogo {
    private static Jogo instancia; 
    private Jogo() {
        jogadores = new ArrayList<>();
        tabuleiro = new Tabuleiro();
        jogadorAtual = 0;
    }

    public static Jogo getInstancia() {
        if (instancia == null) {
            instancia = new Jogo();
        }
        return instancia;
    }

    private List<Jogador> jogadores;
    private Tabuleiro tabuleiro;
    private int jogadorAtual; 
    private List<Observer> observadores = new ArrayList<>();
    
    private String ultimaCartaGlobal; 
    
    private String ultimoEventoLog; 

    public void adicionarJogador(Jogador j) {
        jogadores.add(j);
        notificarObservadores();
    }

    public void iniciarPartida() {
        jogadorAtual = 0;
        notificarObservadores();
    }

    public Jogador getJogadorAtual() {
        return jogadores.get(jogadorAtual);
    }
    
    public int getIndiceJogadorAtual() {
        return this.jogadorAtual;
    }

    public int getIndicePorNome(String nome) {
        if (nome == null) return -1;
        for (int i = 0; i < jogadores.size(); i++) {
            if (nome.equals(jogadores.get(i).getNome())) {
                return i;
            }
        }
        return -1;
    }

    public List<Jogador> getJogadores() {
        return jogadores;
    }
    
    public double getJogadorSaldo(int indice) {
        if (indice >= 0 && indice < jogadores.size()) {
            return jogadores.get(indice).getSaldo();
        }
        return 0.0;
    }

    public Set<String> getPropriedadesDoJogador(int indice) {
        if (indice >= 0 && indice < jogadores.size()) {
            return jogadores.get(indice).getPropriedades().stream()
                .map(Propriedade::getNome)
                .collect(Collectors.toSet());
        }
        return null;
    }

    public void proximaJogada(int valorDado) {
        Jogador j = getJogadorAtual();
        j.mover(valorDado, tabuleiro.tamanho());
        tabuleiro.verificarCasaAtual(j);
        avancarJogadorDaVez();
        notificarObservadores();
    }

    private void avancarJogadorDaVez() {
        jogadorAtual = (jogadorAtual + 1) % jogadores.size();
    }
    
    void moverJogadorAtual(int casas) {
        this.ultimaCartaGlobal = null;
        this.ultimoEventoLog = null;
        
        Jogador atual = getJogadorAtual();
        if (atual != null && !atual.estaPreso()) {
            atual.mover(casas, tabuleiro.tamanho());
            tabuleiro.verificarCasaAtual(atual); 
            
            notificarObservadores();
        }
    }
    
    public void encerrarTurno() {
        avancarJogadorDaVez();
        System.out.println("Turno encerrado. Próximo jogador: " + getJogadorAtual().getNome());
        notificarObservadores();
    }
    
    public void setUltimaCartaGlobal(String id) {
        ultimaCartaGlobal = id;
    }

    public String getUltimaCartaGlobal() {
        return ultimaCartaGlobal;
    }

    public void setUltimoEventoLog(String msg) {
        System.out.println(msg); 
        this.ultimoEventoLog = msg;
    }

    public String getUltimoEventoLog() {
        return this.ultimoEventoLog;
    }
    
    public boolean comprarPropriedadeAtual() {
        Jogador j = getJogadorAtual();
        Propriedade p = tabuleiro.getCasa(j.getPosicao());
        j.comprarPropriedade(p); 
        notificarObservadores(); 
        return p.getDono() == j; 
    }
    
    public boolean construirCasa(String nomePropriedade) {
        Jogador j = getJogadorAtual();
        Propriedade p = tabuleiro.getPropriedadePorNome(nomePropriedade);

        if (p != null && p.getDono() == j) {
            double custoConstrucao = p.getPreco() * 0.5;
            if (j.getSaldo() >= custoConstrucao && p.getCasas() < 4) {
                p.construirCasa();
                j.pagar(custoConstrucao, "Banco"); 
                setUltimoEventoLog("🏠 " + j.getNome() + " construiu 1 casa em " + p.getNome()); 
                notificarObservadores();
                return true;
            }
        }
        setUltimoEventoLog("❌ Não foi possível construir casa em " + nomePropriedade);
        notificarObservadores();
        return false;
    }
    
    public boolean construirHotel(String nomePropriedade) {
        Jogador j = getJogadorAtual();
        Propriedade p = tabuleiro.getPropriedadePorNome(nomePropriedade);

        if (p != null && p.getDono() == j) {
            double custoConstrucao = p.getPreco() * 0.5; 
            if (j.getSaldo() >= custoConstrucao && p.getCasas() == 4 && !p.temHotel()) {
                p.construirHotel();
                j.pagar(custoConstrucao, "Banco"); 
                setUltimoEventoLog("🏨 " + j.getNome() + " construiu 1 hotel em " + p.getNome());
                notificarObservadores();
                return true;
            }
        }
        setUltimoEventoLog("❌ Não foi possível construir hotel em " + nomePropriedade);
        notificarObservadores();
        return false;
    }
    
    public boolean venderPropriedade(String nomePropriedade) {
        Jogador j = getJogadorAtual();
        Propriedade p = tabuleiro.getPropriedadePorNome(nomePropriedade);

        if (p != null && p.getDono() == j) {
            double valorVenda = p.getPreco() * 0.5;
            j.receber(valorVenda, "Banco"); 
            j.removerPropriedade(p); 
            p.setDono(null); 
            setUltimoEventoLog("🏦 " + j.getNome() + " vendeu " + p.getNome() + " ao banco.");
            notificarObservadores();
            return true;
        }
        setUltimoEventoLog("❌ Não foi possível vender " + nomePropriedade);
        notificarObservadores();
        return false;
    }

    public void adicionarObservador(Observer o) {
        observadores.add((Observer) o);
    }

    public void removerObservador(Observer o) {
        observadores.remove(o);
    }

    public void notificarObservadores() {
        for (Observer o : observadores) {
            o.atualizar();
        }
    }
    
    public Tabuleiro getTabuleiro() {
        return tabuleiro;
    }
    
    public void salvarEstado(String nomeArquivo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(nomeArquivo))) {
            
            // 1. Estado Global (Jogador Atual)
            writer.println("JOGADOR_ATUAL|" + this.jogadorAtual);
            writer.println("---JOGADORES---");
            
            // 2. Estado dos Jogadores
            for (Jogador jogador : jogadores) {
                String linhaJogador = String.format("JOGADOR|%s|%.2f|%d|%s|%s|%s|%d|%s",
                    jogador.getNome(),
                    jogador.getSaldo(),
                    jogador.getPosicao(),
                    jogador.estaPreso(),
                    jogador.estaFalido(),
                    jogador.temCartaoSaidaLivre(),
                    jogador.getDuplasSeguidas(),
                    jogador.getCorPiao()
                );
                writer.println(linhaJogador);
            }
            
            writer.println("---PROPRIEDADES---");
            
            // 3. Estado das Propriedades (Dono, Casas, Hotéis)
            for (Propriedade p : tabuleiro.getTodasPropriedades()) {
                // Salva apenas propriedades que podem ser compradas (Preço > 0)
                if (p.getPreco() > 0) {
                     String donoNome = p.temDono() ? p.getDono().getNome() : "NULL";
                     String linhaPropriedade = String.format("PROPRIEDADE|%s|%d|%s|%s",
                        p.getNome(),
                        p.getCasas(),
                        p.temHotel(),
                        donoNome
                     );
                     writer.println(linhaPropriedade);
                }
            }

            setUltimoEventoLog("✅ Jogo salvo em: " + nomeArquivo);
        } catch (IOException e) {
            setUltimoEventoLog("❌ Erro ao salvar o jogo: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public boolean carregarEstado(String nomeArquivo) {
        try (Scanner scanner = new Scanner(new File(nomeArquivo))) {
            
            // 1. Carrega Estado Global
            String linhaAtual = scanner.nextLine();
            if (linhaAtual.startsWith("JOGADOR_ATUAL")) {
                this.jogadorAtual = Integer.parseInt(linhaAtual.split("\\|")[1].trim());
            }

            // 2. Limpar estado atual (essencial)
            jogadores.clear();
            // TODO: Se o Tabuleiro tiver um estado inicial mutável, chame um método para resetá-lo aqui.

            // 3. Carrega Jogadores
            if (!scanner.nextLine().equals("---JOGADORES---")) throw new IOException("Formato de arquivo inválido (JOGADORES)");
            while (scanner.hasNextLine()) {
                linhaAtual = scanner.nextLine();
                if (linhaAtual.equals("---PROPRIEDADES---")) break;
                
                String[] partes = linhaAtual.split("\\|");
                if (partes.length >= 9 && partes[0].equals("JOGADOR")) {
                    String nome = partes[1];
                    //double saldo = Double.parseDouble(partes[2]);
                    double saldo = Double.parseDouble(partes[2].replace(',', '.'));
                    int posicao = Integer.parseInt(partes[3]);
                    boolean preso = Boolean.parseBoolean(partes[4]);
                    boolean falido = Boolean.parseBoolean(partes[5]);
                    boolean cartaoLivre = Boolean.parseBoolean(partes[6]);
                    int duplas = Integer.parseInt(partes[7]);
                    String corPiao = partes[8];
                    
                    // Recria o jogador usando o construtor existente
                    Jogador novoJ = new Jogador(nome, 0, corPiao); 
                    
                    // Restaura o estado salvo
                    novoJ.setSaldo(saldo);
                    novoJ.setPosicao(posicao);
                    novoJ.setPreso(preso);
                    novoJ.setFalido(falido);
                    novoJ.setTemCartaoSaidaLivre(cartaoLivre);
                    novoJ.setDuplasSeguidas(duplas);
                    jogadores.add(novoJ);
                }
            }

            // 4. Carrega Propriedades (restaura donos, casas, hotéis)
            while (scanner.hasNextLine()) {
                linhaAtual = scanner.nextLine();
                String[] partes = linhaAtual.split("\\|");
                if (partes.length >= 5 && partes[0].equals("PROPRIEDADE")) {
                    String nomePropriedade = partes[1];
                    int casas = Integer.parseInt(partes[2]);
                    boolean hotel = Boolean.parseBoolean(partes[3]);
                    String donoNome = partes[4].equals("NULL") ? null : partes[4];
                    
                    Propriedade p = tabuleiro.getPropriedadePorNome(nomePropriedade);
                    if (p != null) {
                        p.setCasas(casas);
                        p.setHotel(hotel);
                        p.setDono(null); // Reseta o dono
                        
                        // Encontra o jogador e atribui a propriedade de volta
                        if (donoNome != null) {
                            Jogador dono = jogadores.stream()
                                    .filter(j -> j.getNome().equals(donoNome))
                                    .findFirst().orElse(null);
                            
                            if (dono != null) {
                                p.setDono(dono); 
                                dono.getPropriedades().add(p); // Adiciona a propriedade à lista do jogador
                            }
                        }
                    }
                }
            }

            setUltimoEventoLog("✅ Jogo carregado com sucesso!");
            notificarObservadores();
            return true;
            
        } catch (FileNotFoundException e) {
            setUltimoEventoLog("❌ Arquivo de salvamento não encontrado: " + nomeArquivo);
            return false;
        } catch (IOException | NumberFormatException e) {
            setUltimoEventoLog("❌ Erro ao carregar o jogo: Formato inválido ou dados corrompidos. " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
}