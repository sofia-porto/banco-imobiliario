package view;

import java.awt.*;
import java.awt.event.*;
import model.*;
import controller.JogoController; 

class PainelJogadorView extends Panel implements Observer {
    private static final long serialVersionUID = 1L;

    private JogoFacade jogo;
    private JogoController controller; 

    private Label lblNome;
    private Label lblSaldo;
    private Choice comboPropriedades;
    private Button btnCasa;
    private Button btnHotel;
    private Button btnVender;
    private Button btnEncerrar;
    private Button btnComprar;

    public PainelJogadorView(JogoFacade jogo, JogoController controller) {
        this.jogo = jogo;
        this.controller = controller; 
        
        setLayout(new BorderLayout(10, 10)); 
        setBackground(new Color(245, 245, 245));
        
        Panel painelInfo = new Panel(new GridLayout(2, 1));
        lblNome = new Label("Jogador: ");
        lblNome.setFont(new Font("Arial", Font.BOLD, 16));
        painelInfo.add(lblNome);

        lblSaldo = new Label("Saldo: ");
        lblSaldo.setFont(new Font("Arial", Font.PLAIN, 14));
        painelInfo.add(lblSaldo);
        
        add(painelInfo, BorderLayout.NORTH);

        Panel painelAcoes = new Panel(new GridLayout(6, 1, 5, 5));
        
        btnComprar = new Button("Comprar Propriedade");
        btnComprar.setFont(new Font("Arial", Font.BOLD, 12));
        painelAcoes.add(btnComprar);

        painelAcoes.add(new Label("Ações em Propriedades:", Label.CENTER));
        
        comboPropriedades = new Choice();
        comboPropriedades.add("Selecione uma propriedade");
        painelAcoes.add(comboPropriedades);

        btnCasa = new Button("Construir Casa");
        btnHotel = new Button("Construir Hotel");
        btnVender = new Button("Vender Propriedade");
        
        painelAcoes.add(btnCasa);
        painelAcoes.add(btnHotel);
        painelAcoes.add(btnVender);
        
        Panel painelCentral = new Panel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        painelCentral.add(painelAcoes);
                
        add(painelCentral, BorderLayout.CENTER);
        
        btnEncerrar = new Button("Encerrar Turno"); 
        btnEncerrar.setFont(new Font("Arial", Font.BOLD, 14));
        add(btnEncerrar, BorderLayout.SOUTH);

        configurarEventos();
        atualizarBotoesAcaoPropriedade(false);
        configurarListenerPropriedades();
    }


    private void configurarEventos() {
        btnComprar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.comprarPropriedadeAtual();
            }
        });
        
        btnCasa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selecionada = comboPropriedades.getSelectedItem();
                controller.construirCasa(selecionada);
            }
        });

        btnHotel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selecionada = comboPropriedades.getSelectedItem();
                controller.construirHotel(selecionada);
            }
        });

        btnVender.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selecionada = comboPropriedades.getSelectedItem();
                controller.venderPropriedade(selecionada);
            }
        });
        
        btnEncerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.encerrarTurnoEChamarProximo();
                
                JanelaDadosView janelaDados = new JanelaDadosView(jogo, controller);
                janelaDados.abrirParaJogadorAtual();
            }
        });
    }

    private void configurarListenerPropriedades() {
        comboPropriedades.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String selecionada = comboPropriedades.getSelectedItem();
                
                boolean propriedadeRealSelecionada = !selecionada.equals("Selecione uma propriedade");
                
                atualizarBotoesAcaoPropriedade(propriedadeRealSelecionada);
            }
        });
    }

    private void atualizarBotoesAcaoPropriedade(boolean habilitar) {
        btnCasa.setEnabled(habilitar);
        btnHotel.setEnabled(habilitar);
        btnVender.setEnabled(habilitar);
    }

    @Override
    public void atualizar() {
        int indiceAtual = jogo.getIndiceJogadorAtual();
        
        lblNome.setText("Jogador: " + jogo.getJogadorNome(indiceAtual));
        lblSaldo.setText("Saldo: R$" + jogo.getJogadorSaldo(indiceAtual));

        comboPropriedades.removeAll();
        comboPropriedades.add("Selecione uma propriedade");
        String[] props = jogo.getPropriedadesDoJogador(indiceAtual);
        for (String nome : props) {
            comboPropriedades.add(nome);
        }
        
        atualizarBotoesAcaoPropriedade(false); 

        int posAtual = jogo.getJogadorPosicao(indiceAtual);
        boolean podeComprar = !jogo.propriedadeTemDono(posAtual) && jogo.getPropriedadePreco(posAtual) > 0;
        btnComprar.setEnabled(podeComprar); 

        repaint();
    }
}