package model;

public interface Observer {
    void atualizar();
}
