package view;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Box;
import java.awt.event.*;
import javax.swing.BoxLayout;
import model.JogoFacade;
import model.Observer;
import controller.JogoController;

public class JanelaPrincipalView extends Frame implements Observer {
    
    private JogoFacade jogo;
    private JogoController controller;

    private TabuleiroView tabuleiroView;
    private PainelJogadorView painelJogadorView;
    private PainelLogFinanceiroView painelLogFinanceiroView; 

    public JanelaPrincipalView(JogoFacade jogo, JogoController controller) {
        this.jogo = jogo;
        this.controller = controller;

        this.jogo.adicionarObservador(this);

        setTitle("Banco Imobiliário");
        setSize(1100, 840);
        setLayout(new BorderLayout());

        tabuleiroView = new TabuleiroView(jogo, controller);
        add(tabuleiroView, BorderLayout.CENTER); 

        Panel painelLateral = new Panel();
        
        painelLateral.setLayout(new BoxLayout(painelLateral, BoxLayout.Y_AXIS)); 
        painelLateral.setPreferredSize(new Dimension(260, 800));

        painelJogadorView = new PainelJogadorView(jogo, controller);
        painelLogFinanceiroView = new PainelLogFinanceiroView(jogo); 

        Button btnSalvar = new Button("Salvar Jogo");
        btnSalvar.setFont(new Font("Arial", Font.BOLD, 14));
        btnSalvar.setPreferredSize(new Dimension(250, 30)); 
        
        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.salvarJogo();
            }
        });
        
        Button btnEncerrarJogo = new Button("Encerrar Jogo");
        btnEncerrarJogo.setFont(new Font("Arial", Font.BOLD, 14));
        btnEncerrarJogo.setBackground(Color.RED); 
        btnEncerrarJogo.setPreferredSize(new Dimension(250, 30));
        
        btnEncerrarJogo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String rankingFinal = controller.encerrarJogo();
                
                Dialog rankingDialog = new Dialog(JanelaPrincipalView.this, "Resultado Final", true); 
                rankingDialog.setLayout(new BorderLayout());
                rankingDialog.setSize(400, 300);
                
                TextArea rankingTextArea = new TextArea(rankingFinal, 10, 40, TextArea.SCROLLBARS_VERTICAL_ONLY);
                rankingTextArea.setEditable(false);
                rankingTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
                
                rankingDialog.add(rankingTextArea, BorderLayout.CENTER);
                
                Button closeButton = new Button("Fechar Jogo");
                closeButton.addActionListener(evt -> {
                    rankingDialog.dispose();
                    System.exit(0); 
                });
                Panel buttonPanel = new Panel();
                buttonPanel.add(closeButton);
                rankingDialog.add(buttonPanel, BorderLayout.SOUTH);
                
                rankingDialog.setLocationRelativeTo(JanelaPrincipalView.this);
                rankingDialog.setVisible(true);
            }
        });
                
        painelLateral.add(painelJogadorView);
        painelLateral.add(Box.createVerticalStrut(15)); 

        painelLateral.add(btnSalvar);
        painelLateral.add(Box.createVerticalStrut(15));
        painelLateral.add(btnEncerrarJogo); 
        painelLateral.add(Box.createVerticalStrut(15));
        painelLateral.add(painelLogFinanceiroView);
        
        add(painelLateral, BorderLayout.EAST);
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.out.println("Saindo do jogo...");
                dispose();
                System.exit(0); 
            }
        });

        jogo.adicionarObservador(tabuleiroView); 
        jogo.adicionarObservador(painelJogadorView);
        jogo.adicionarObservador(painelLogFinanceiroView); 
    }
    
    public void exibir() {
        setVisible(true);
        tabuleiroView.requestFocus(); 
        
        boolean jaJogou = jogo.jogadorAtualJaJogouNesteTurno();
        int duplas = jogo.getDuplasSeguidasJogadorAtual();
        
        boolean podeJogar = !jaJogou || (duplas > 0 && !jogo.jogadorAtualEstaPreso());
        
        if (podeJogar) {
            JanelaDadosView janelaDados = new JanelaDadosView(jogo, controller);
            janelaDados.abrirParaJogadorAtual();
        } else {
            System.out.println("JanelaPrincipalView: Jogador atual já encerrou a fase de dados. Não abrindo JanelaDadosView.");
        }
    }

    @Override
    public void atualizar() {}
}