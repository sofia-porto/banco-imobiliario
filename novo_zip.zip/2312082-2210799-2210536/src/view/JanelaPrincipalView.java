package view;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Box;
import java.awt.event.*;
import javax.swing.BoxLayout;
import model.JogoFacade;
import model.Observer;
import controller.JogoController;

public class JanelaPrincipalView extends Frame implements Observer {
    
    private JogoFacade jogo;
    private JogoController controller;

    private TabuleiroView tabuleiroView;
    private PainelJogadorView painelJogadorView;
    private PainelLogFinanceiroView painelLogFinanceiroView; 

    public JanelaPrincipalView(JogoFacade jogo, JogoController controller) {
        this.jogo = jogo;
        this.controller = controller;

        this.jogo.adicionarObservador(this);

        setTitle("Banco Imobiliário");
        setSize(1100, 840);
        setLayout(new BorderLayout());

        tabuleiroView = new TabuleiroView(jogo, controller);
        add(tabuleiroView, BorderLayout.CENTER); 

        Panel painelLateral = new Panel();
        
        painelLateral.setLayout(new BoxLayout(painelLateral, BoxLayout.Y_AXIS)); 
        painelLateral.setPreferredSize(new Dimension(260, 800));

        painelJogadorView = new PainelJogadorView(jogo, controller);
        painelLogFinanceiroView = new PainelLogFinanceiroView(jogo); 

        Button btnSalvar = new Button("💾 Salvar Jogo");
        btnSalvar.setFont(new Font("Arial", Font.BOLD, 14));
        // Definir um tamanho fixo para o botão se estiver usando BoxLayout sem Box.createHorizontalGlue
        btnSalvar.setPreferredSize(new Dimension(250, 30)); 
        
        // Alinhamento central para o botão (necessário para BoxLayout Y_AXIS)
     //   Box.createHorizontalGlue()
        
        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.salvarJogo();
            }
        });
        
        
        
        painelLateral.add(painelJogadorView);
        painelLateral.add(Box.createVerticalStrut(15)); 

        // 3. Botão de Salvar
        painelLateral.add(btnSalvar);

        // 4. Espaçador
        painelLateral.add(Box.createVerticalStrut(15));
        painelLateral.add(painelLogFinanceiroView);
        
        add(painelLateral, BorderLayout.EAST);
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.out.println("Saindo do jogo...");
                dispose();
                System.exit(0); 
            }
        });

        jogo.adicionarObservador(tabuleiroView); 
        jogo.adicionarObservador(painelJogadorView);
        jogo.adicionarObservador(painelLogFinanceiroView); 
    }

    public void exibir() {
        setVisible(true);
        tabuleiroView.requestFocus(); 

        JanelaDadosView janelaDados = new JanelaDadosView(jogo, controller);
        janelaDados.abrirParaJogadorAtual();
    }

    @Override
    public void atualizar() {}
}