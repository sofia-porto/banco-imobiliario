package model;

import java.util.ArrayList;
import java.util.Comparator;
import java.io.*; 
import java.util.Scanner;
import java.util.Set;
import java.util.List;
import java.util.stream.Collectors;

class Jogo {
    private static Jogo instancia; 
    private boolean dadosDiferentesLancados = false;
    private Jogo() {
        jogadores = new ArrayList<>();
        tabuleiro = new Tabuleiro();
        jogadorAtual = 0;
        banco = new Banco(200000); 
    }
    
    public static Jogo getInstancia() {
        if (instancia == null) {
            instancia = new Jogo();
        }
        return instancia;
    }

    private List<Jogador> jogadores;
    private Tabuleiro tabuleiro;
    private int jogadorAtual; 
    private List<Observer> observadores = new ArrayList<>();
    private Banco banco; 
    
    private String ultimaCartaGlobal; 
    
    private String ultimoEventoLog; 
    
    boolean getDadosDiferentesLancados() {
        return dadosDiferentesLancados;
    }

    void setDadosDiferentesLancados(boolean valor) {
        this.dadosDiferentesLancados = valor;
    }


    public double get_saldo_banco() {
    	return banco.getSaldo();
    }
    
    public void aumentarSaldoBanco(double valor) {
        this.banco.receber(valor);
        notificarObservadores();
    }
    
    public void adicionarJogador(Jogador j) {
        jogadores.add(j);
        notificarObservadores();
    }

    public void iniciarPartida() {
        jogadorAtual = 0;
        notificarObservadores();
    }

    public Jogador getJogadorAtual() {
        return jogadores.get(jogadorAtual);
    }
    
    public int getIndiceJogadorAtual() {
        return this.jogadorAtual;
    }

    public int getIndicePorNome(String nome) {
        if (nome == null) return -1;
        for (int i = 0; i < jogadores.size(); i++) {
            if (nome.equals(jogadores.get(i).getNome())) {
                return i;
            }
        }
        return -1;
    }

    public List<Jogador> getJogadores() {
        return jogadores;
    }
    
    public double getJogadorSaldo(int indice) {
        if (indice >= 0 && indice < jogadores.size()) {
            return jogadores.get(indice).getSaldo();
        }
        return 0.0;
    }

    public Set<String> getPropriedadesDoJogador(int indice) {
        if (indice >= 0 && indice < jogadores.size()) {
            return jogadores.get(indice).getPropriedades().stream()
                .map(Propriedade::getNome)
                .collect(Collectors.toSet());
        }
        return null;
    }

    public void proximaJogada(int valorDado) {
        Jogador j = getJogadorAtual();
        j.mover(valorDado, tabuleiro.tamanho());
        tabuleiro.verificarCasaAtual(j);
        avancarJogadorDaVez();
        notificarObservadores();
    }

    private void avancarJogadorDaVez() {
        jogadorAtual = (jogadorAtual + 1) % jogadores.size();
    }
    
    public String encerrarJogoEGerarRanking() {
        for (Jogador jogador : jogadores) {
            List<Propriedade> propriedadesParaVender = new ArrayList<>(jogador.getPropriedades());
            
            for (Propriedade p : propriedadesParaVender) {
              
                venderPropriedade(p.getNome()); 
                
            }
        }
        
        class RankingItem {
            private final String nome;
            private final double valorTotal;
            
            public RankingItem(String nome, double valorTotal) {
                this.nome = nome;
                this.valorTotal = valorTotal;
            }
            public String getNome() { return nome; }
            public double getValorTotal() { return valorTotal; }
        }
        
        List<RankingItem> ranking = jogadores.stream()
            .map(j -> new RankingItem(j.getNome(), j.calcularValorTotal()))
            .sorted(Comparator.comparingDouble(RankingItem::getValorTotal).reversed()) // Ordem decrescente
            .collect(Collectors.toList());
            
        StringBuilder resultado = new StringBuilder("💰 Ranking Final (Valor Total):\n");
        for (int i = 0; i < ranking.size(); i++) {
            RankingItem item = ranking.get(i);
            resultado.append(String.format("%dº Lugar: %s (R$ %,.2f)\n", 
                                           i + 1, 
                                           item.getNome(), 
                                           item.getValorTotal()));
        }
        
        setUltimoEventoLog("🏆 Jogo Encerrado. Ranking Final Calculado.");
        notificarObservadores();
        return resultado.toString();
    }
    
    void moverJogadorAtual(int casas) {
        this.ultimaCartaGlobal = null;
        this.ultimoEventoLog = null;
        
        Jogador atual = getJogadorAtual();
        if (atual != null && !atual.estaPreso()) {
            atual.mover(casas, tabuleiro.tamanho());
            tabuleiro.verificarCasaAtual(atual); 
            
            notificarObservadores();
        }
    }
    
    void registrarDuplas() {
    	Jogador atual = getJogadorAtual();
    	atual.registrarDupla();
    }
    
    public void encerrarTurno() {
        avancarJogadorDaVez();
        System.out.println("Turno encerrado. Próximo jogador: " + getJogadorAtual().getNome());
        getJogadorAtual().setJaJogouNesteTurno(false); 
        this.dadosDiferentesLancados = false;
        notificarObservadores();
    }
    

    public void setUltimaCartaGlobal(String id) {
        ultimaCartaGlobal = id;
    }

    public String getUltimaCartaGlobal() {
        return ultimaCartaGlobal;
    }

    public void setUltimoEventoLog(String msg) {
        System.out.println(msg); 
        this.ultimoEventoLog = msg;
        notificarObservadores();
    }

    public String getUltimoEventoLog() {
        return this.ultimoEventoLog;
    }
    
    public void adicionarObservador(Observer o) {
        observadores.add((Observer) o);
    }

    public void removerObservador(Observer o) {
        observadores.remove(o);
    }

    public void notificarObservadores() {
        for (Observer o : observadores) {
            o.atualizar();
        }
    }
    
    public Tabuleiro getTabuleiro() {
        return tabuleiro;
    }
    
    public boolean comprarPropriedadeAtual() {
        Jogador j = getJogadorAtual();
        Propriedade p = tabuleiro.getCasa(j.getPosicao());
        j.comprarPropriedade(p,this.banco); 
        notificarObservadores(); 
        return p.getDono() == j; 
    }
    
    public boolean construirCasa(String nomePropriedade) {
        Jogador j = getJogadorAtual();
        Propriedade p = tabuleiro.getPropriedadePorNome(nomePropriedade);
        
        if (p != null && p.getDono() == j) {
            double custoConstrucao = p.getPreco() * 0.5;
            if (j.getSaldo() >= custoConstrucao && p.getCasas() < 4) {
                p.construirCasa();
                j.pagar(custoConstrucao, "Banco"); 
                this.banco.receber(custoConstrucao); // Banco recebe o custo da construção
                setUltimoEventoLog("🏠 " + j.getNome() + " construiu 1 casa em " + p.getNome()); 
                return true;
            }
        }
        setUltimoEventoLog("❌ Não foi possível construir casa em " + nomePropriedade);
        return false;
    }
    
    public boolean construirHotel(String nomePropriedade) {
        Jogador j = getJogadorAtual();
        Propriedade p = tabuleiro.getPropriedadePorNome(nomePropriedade);

        if (p != null && p.getDono() == j) {
            double custoConstrucao = p.getPreco() * 0.5; 
            if (j.getSaldo() >= custoConstrucao && p.getCasas() == 4 && !p.temHotel()) {
                p.construirHotel();
                j.pagar(custoConstrucao, "Banco"); 
                this.banco.receber(custoConstrucao); // Banco recebe o custo da construção
                setUltimoEventoLog("🏨 " + j.getNome() + " construiu 1 hotel em " + p.getNome());
                return true;
            }
        }
        setUltimoEventoLog("❌ Não foi possível construir hotel em " + nomePropriedade);
        return false;
    }
    
    public boolean venderPropriedade(String nomePropriedade) {
        Jogador j = getJogadorAtual();
        Propriedade p = tabuleiro.getPropriedadePorNome(nomePropriedade);

        if (p != null && p.getDono() == j) {
            double valorVendaBenfeitoria = p.getPreco() * 0.25;
            double valorTotalRecebido = 0.0;
            
            if (p.temHotel()) {
                p.setHotel(false);
                valorTotalRecebido += valorVendaBenfeitoria;
                j.receber(valorTotalRecebido,"Banco");
                setUltimoEventoLog("🏠 " + j.getNome() + " vendeu 1 hotel em " + p.getNome());
            }

            if (p.getCasas() > 0) {
                int numCasas = p.getCasas();
                double valorCasas = numCasas * valorVendaBenfeitoria;
                
                p.setCasas(0);
                valorTotalRecebido += valorCasas;
                j.receber(valorTotalRecebido,"Banco");
                setUltimoEventoLog("🏠 " + j.getNome() + " vendeu " + numCasas + " casas em " + p.getNome());
            }
            
            if (valorTotalRecebido > 0) {
                j.receber(valorTotalRecebido, "Banco");
            }

            double valorVendaPropriedade = p.getPreco() * 0.5;
            j.receber(valorVendaPropriedade, "Banco"); 
            this.banco.pagar(valorVendaPropriedade);
            j.removerPropriedade(p);    
            p.setDono(null);    
            setUltimoEventoLog("🏦 " + j.getNome() + " hipotecou/vendeu " + p.getNome() + " ao banco.");
            notificarObservadores();
            return true;
        }
        setUltimoEventoLog("❌ Não foi possível vender " + nomePropriedade);
        return false;
    }

    public void salvarEstado(String nomeArquivo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(nomeArquivo))) {
            
            writer.println("JOGADOR_ATUAL|" + this.jogadorAtual);
            writer.println("SALDO_BANCO|" + this.banco.getSaldo()); 
            writer.println("DADOS_DIFERENTES_LANCADOS|" + this.dadosDiferentesLancados);
            writer.println("---JOGADORES---");
            
            for (Jogador jogador : jogadores) {
                String linhaJogador = String.format("JOGADOR|%s|%.2f|%d|%s|%s|%s|%d|%s|%s",
                    jogador.getNome(),
                    jogador.getSaldo(),
                    jogador.getPosicao(),
                    jogador.estaPreso(),
                    jogador.estaFalido(),
                    jogador.temCartaoSaidaLivre(),
                    jogador.getDuplasSeguidas(),
                    jogador.getCorPiao(), 
                    jogador.jaJogouNesteTurno()
                );
                writer.println(linhaJogador);
            }
            
            writer.println("---PROPRIEDADES---");
            
            for (Propriedade p : tabuleiro.getTodasPropriedades()) {
                if (p.getPreco() > 0) {
                     String donoNome = p.temDono() ? p.getDono().getNome() : "NULL";
                     String linhaPropriedade = String.format("PROPRIEDADE|%s|%d|%s|%s",
                         p.getNome(),
                         p.getCasas(),
                         p.temHotel(),
                         donoNome
                     );
                     writer.println(linhaPropriedade);
                }
            }

            setUltimoEventoLog("✅ Jogo salvo em: " + nomeArquivo);
        } catch (IOException e) {
            setUltimoEventoLog("❌ Erro ao salvar o jogo: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public boolean carregarEstado(String nomeArquivo) {

        try (Scanner scanner = new Scanner(new File(nomeArquivo))) {

            String linhaAtual = scanner.nextLine();

            if (linhaAtual.startsWith("JOGADOR_ATUAL")) {

                this.jogadorAtual = Integer.parseInt(linhaAtual.split("\\|")[1].trim());

            }
            linhaAtual = scanner.nextLine();
            if (linhaAtual.startsWith("SALDO_BANCO")) {
                double saldoBanco = Double.parseDouble(linhaAtual.split("\\|")[1].trim().replace(',', '.'));
                this.banco.setSaldo(saldoBanco);
            } else {
                throw new IOException("Formato de arquivo inválido (SALDO_BANCO)");
            }
            
            linhaAtual = scanner.nextLine();
            if (linhaAtual.startsWith("DADOS_DIFERENTES_LANCADOS")) {
                this.dadosDiferentesLancados = Boolean.parseBoolean(linhaAtual.split("\\|")[1].trim());
            } else {
                throw new IOException("Formato de arquivo inválido (DADOS_DIFERENTES_LANCADOS)");
            }
            
            jogadores.clear();

            if (!scanner.nextLine().equals("---JOGADORES---")) throw new IOException("Formato de arquivo inválido (JOGADORES)");
            while (scanner.hasNextLine()) {
                linhaAtual = scanner.nextLine();
                if (linhaAtual.equals("---PROPRIEDADES---")) break;
                String[] partes = linhaAtual.split("\\|");
                if (partes.length >= 9 && partes[0].equals("JOGADOR")) {
                    String nome = partes[1];
                    double saldo = Double.parseDouble(partes[2].replace(',', '.'));
                    int posicao = Integer.parseInt(partes[3]);
                    boolean preso = Boolean.parseBoolean(partes[4]);
                    boolean falido = Boolean.parseBoolean(partes[5]);
                    boolean cartaoLivre = Boolean.parseBoolean(partes[6]);
                    int duplas = Integer.parseInt(partes[7]);
                    String corPiao = partes[8];
                    boolean jaJogou = Boolean.parseBoolean(partes[9]);
                    Jogador novoJ = new Jogador(nome, 0, corPiao); 

                    novoJ.setSaldo(saldo);
                    novoJ.setPosicao(posicao);
                    novoJ.setPreso(preso);
                    novoJ.setFalido(falido);
                    novoJ.setTemCartaoSaidaLivre(cartaoLivre);
                    novoJ.setJaJogouNesteTurno(jaJogou);
                    novoJ.setDuplasSeguidas(duplas);
                    jogadores.add(novoJ);
                }
            }

            while (scanner.hasNextLine()) {
                linhaAtual = scanner.nextLine();
                String[] partes = linhaAtual.split("\\|");
                if (partes.length >= 5 && partes[0].equals("PROPRIEDADE")) {
                    String nomePropriedade = partes[1];
                    int casas = Integer.parseInt(partes[2]);
                    boolean hotel = Boolean.parseBoolean(partes[3]);
                    String donoNome = partes[4].equals("NULL") ? null : partes[4];

                    Propriedade p = tabuleiro.getPropriedadePorNome(nomePropriedade);
                    if (p != null) {
                        p.setCasas(casas);
                        p.setHotel(hotel);
                        p.setDono(null); 

                        if (donoNome != null) {
                            Jogador dono = jogadores.stream()
                                    .filter(j -> j.getNome().equals(donoNome))
                                    .findFirst().orElse(null);

                            if (dono != null) {
                                p.setDono(dono); 
                                dono.getPropriedades().add(p);
                            }
                        }
                    }
                }
            }

            setUltimoEventoLog("✅ Jogo carregado com sucesso!");
            notificarObservadores();
            return true;
        } catch (FileNotFoundException e) {
            setUltimoEventoLog("❌ Arquivo de salvamento não encontrado: " + nomeArquivo);
            return false;
        } catch (IOException | NumberFormatException e) {
            setUltimoEventoLog("❌ Erro ao carregar o jogo: Formato inválido ou dados corrompidos. " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}